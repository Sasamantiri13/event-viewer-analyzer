/**
 * HeuristicEngine.gs — Offline Analysis Engine + KB Enrichment
 * Generates structured diagnostic reports when AI APIs are unavailable.
 */

function generateHeuristicReport(logs, categoryCounts, timeFrameText, isMultiFileCorrelation) {
  var totalLogs = logs.length;
  var criticalLogs = logs.filter(function(l) { return l.level === "Critical"; });
  var errorLogs = logs.filter(function(l) { return l.level === "Error"; });
  var warningLogs = logs.filter(function(l) { return l.level === "Warning"; });
  var infoLogs = logs.filter(function(l) { return l.level === "Information"; });

  // Determine overall severity
  var overallSeverity = "Aman (Information)";
  var severityEmoji = "✅";
  if (criticalLogs.length > 0) {
    overallSeverity = "Kritis (Critical)";
    severityEmoji = "🚨";
  } else if (errorLogs.length > 0) {
    overallSeverity = "Kesalahan (Error)";
    severityEmoji = "⚠️";
  } else if (warningLogs.length > 0) {
    overallSeverity = "Peringatan (Warning)";
    severityEmoji = "🔔";
  }

  // Defender codes directory
  var defenderCodesList = [
    { code: "1116", title: "Malware Detection", rec: "Periksa jalur file terinfeksi. Jalankan full scan segera." },
    { code: "1117", title: "Malware Action Taken", rec: "Ancaman telah dinetralisir aman. Terus pantau aktivitas perangkat." },
    { code: "1118", title: "Malware Action Failed", rec: "🚨 SEGERA laksanakan scan offline atau pembersihan manual!" },
    { code: "1119", title: "Remediation Signature Failed", rec: "Perbarui Security Intelligence Defender dengan PowerShell 'Update-MpSignature'." },
    { code: "2011", title: "Security Intelligence Update Failed", rec: "Jalankan 'MpCmdRun.exe -SignatureUpdate' untuk memperbarui tanda tangan virus secara manual." },
    { code: "5001", title: "Real-time Protection Disabled", rec: "Aktifkan kembali proteksi real-time via PowerShell 'Set-MpPreference -DisableRealtimeMonitoring $false'." },
    { code: "5007", title: "Defender Configuration Changed", rec: "Audit perubahan konfigurasi untuk memastikan tidak ada percobaan bypass." },
    { code: "5008", title: "Real-time Protection Failed", rec: "Restart service Defender (Windefend) dan cek adanya konflik driver." },
    { code: "5009", title: "Antivirus is Disabled", rec: "🚨 Aktifkan kembali antivirus segera via Group Policy atau Registry!" },
    { code: "3001", title: "Driver Load Blocked (Code Integrity)", rec: "Mencegah BYOVD. Gunakan driver resmi WHQL dan hapus loader tidak sah." },
    { code: "3002", title: "Image Hash Verification Failed", rec: "Kerusakan berkas sistem terdeteksi. Jalankan 'sfc /scannow'." },
    { code: "3004", title: "Kernel-Mode Signing Violation", rec: "Sertifikat driver kernel tidak sah. Jalankan 'sigverif'." },
    { code: "3091", title: "WDAC Policy Blocked Executive", rec: "File diblokir kebijakan WDAC/AppLocker. Daftarkan pengecualian jika file sah." },
    { code: "3097", title: "Code Integrity Signature Failure", rec: "Gagal memverifikasi tanda tangan pustaka inti. Update sertifikat root." },
    { code: "0x80508015", title: "Scan or Threat Cleanup Error", rec: "Jalankan 'Microsoft Defender Offline Scan'." },
    { code: "0x80070005", title: "Access Denied", rec: "Gunakan alat pembersih bootable steril untuk rootkit." },
    { code: "0x80070422", title: "Service Disabled Error", rec: "Nyalakan service via 'sc config WinDefend start= auto'." },
    { code: "0x80070643", title: "Fatal Installation / Update Error", rec: "Jalankan Windows Update Troubleshooter." }
  ];

  // Match defender codes
  var matchedCodes = [];
  logs.forEach(function(log) {
    var evMatch = defenderCodesList.filter(function(c) {
      return log.eventId && log.eventId.toString() === c.code;
    })[0];
    if (evMatch && !matchedCodes.some(function(m) { return m.code === evMatch.code; })) {
      matchedCodes.push(evMatch);
    }
    defenderCodesList.forEach(function(c) {
      if (c.code.indexOf("0x") === 0 && log.message && log.message.toLowerCase().indexOf(c.code.toLowerCase()) !== -1) {
        if (!matchedCodes.some(function(m) { return m.code === c.code; })) {
          matchedCodes.push(c);
        }
      }
    });
  });

  // KB enrichment
  var kbMatches = [];
  var seenKbIds = {};
  var kbSize = getKBSize();
  
  logs.forEach(function(log) {
    var id = log.eventId ? log.eventId.toString() : null;
    if (!id || seenKbIds[id]) return;
    var kbEntry = lookupKBEntry(id);
    if (kbEntry) {
      seenKbIds[id] = true;
      kbMatches.push({
        eventId: id,
        criticality: kbEntry.criticality || "Unknown",
        summary: kbEntry.summary || "No description"
      });
    }
  });

  // Dominant category
  var categoriesMap = {};
  logs.forEach(function(log) {
    categoriesMap[log.category] = (categoriesMap[log.category] || 0) + 1;
  });
  var dominantCategory = Object.keys(categoriesMap).sort(function(a, b) {
    return categoriesMap[b] - categoriesMap[a];
  })[0] || "Tidak spesifik";

  // Build report
  var md = "### 📊 Laporan Diagnostik Sistem Offline (Mode Heuristik + Knowledge Base)\n\n" +
    "> **Mode Analisis**: 🔒 Offline (Knowledge Base Lokal: " + kbSize + " entri Windows Event ID)\n\n" +
    "1. **Ringkasan Eksekutif (Executive Summary)**\n" +
    "Sistem mendeteksi total **" + totalLogs + " log abnormal** dalam jangka waktu **" + (timeFrameText || "1 jam terakhir") + "**. " +
    "Kategori kendala yang mendominasi adalah **" + dominantCategory + "**. " +
    "Tingkat keparahan keseluruhan dinilai berada pada level **" + overallSeverity + " " + severityEmoji + "**.\n\n" +
    "- Total Kejadian Kritis (Critical): **" + criticalLogs.length + "**\n" +
    "- Total Kesalahan (Error): **" + errorLogs.length + "**\n" +
    "- Total Peringatan (Warning): **" + warningLogs.length + "**\n" +
    "- Total Informasi (Information): **" + infoLogs.length + "**\n\n" +
    "2. **Analisis Kendala Utama (Major Findings & Root Cause)**\n" +
    "Berikut adalah temuan utama dari rincian log yang dimuat:\n";

  if (criticalLogs.length > 0) {
    md += "- **Kegagalan Kritis Terdeteksi**: Terdapat " + criticalLogs.length + " entri tingkat KRITIS dari sumber `" + (criticalLogs[0].source || "N/A") + "` dengan Event ID `" + (criticalLogs[0].eventId || "N/A") + "`.\n";
  }
  if (errorLogs.length > 0) {
    md += "- **Kesalahan Sistem/Aplikasi**: Terdapat " + errorLogs.length + " error terkait modul `" + (errorLogs[0].source || "N/A") + "`.\n";
  }
  if (warningLogs.length > 0) {
    md += "- **Indikasi Peringatan Keamanan**: Ditemukan " + warningLogs.length + " log peringatan dari sumber `" + (warningLogs[0].source || "N/A") + "`.\n";
  }
  md += "- **Sumber Utama Penyebab**: Masalah didominasi oleh ketidakselarasan konfigurasi atau kegagalan pembaruan modul pendukung sistem.\n\n";

  md += "3. **Analisis Defender Endpoint (Bila relevan)**\n";
  if (matchedCodes.length > 0) {
    matchedCodes.forEach(function(m) {
      md += "- **Ditemukan Kode " + m.code + " (" + m.title + ")**: " + m.rec + "\n";
    });
  } else {
    md += "- *Tidak ditemukan Event ID atau HRESULT spesifik Microsoft Defender Endpoint dalam log terfilter saat ini.*\n";
  }
  md += "\n";

  var sectionNum = 4;
  if (kbMatches.length > 0) {
    md += sectionNum + ". **📚 Knowledge Base Windows Event ID (Enrichment Lokal)**\n" +
      "Sistem berhasil mencocokkan **" + kbMatches.length + " Event ID** dengan database pengetahuan Windows:\n";
    kbMatches.slice(0, 15).forEach(function(k) {
      md += "- **Event ID " + k.eventId + "** [" + k.criticality + "]: " + k.summary + "\n";
    });
    if (kbMatches.length > 15) {
      md += "- *...dan " + (kbMatches.length - 15) + " Event ID lainnya.*\n";
    }
    md += "\n";
    sectionNum++;
  }

  if (isMultiFileCorrelation) {
    md += sectionNum + ". **Korelasi Silang 2 Berkas (Smart Multi-File Check)**\n" +
      "- Sistem mendeteksi dua sumber berkas log yang diunggah bersamaan.\n" +
      "- Masalah yang teridentifikasi pada berkas pertama kemungkinan besar memiliki hubungan sebab-akibat dengan kegagalan pada berkas kedua.\n\n";
    sectionNum++;
  }

  md += sectionNum + ". **Rekomendasi Langkah Perbaikan (Actionable Recommendations)**\n" +
    "- **Langkah 1 (PowerShell Keamanan)**: `Update-MpSignature`\n" +
    "- **Langkah 2 (Verifikasi Layanan)**: `sc query WinDefend` lalu `sc start WinDefend`\n" +
    "- **Langkah 3 (Kesehatan Berkas)**: `sfc /scannow` dan `DISM.exe /Online /Cleanup-image /Restorehealth`\n\n";
  sectionNum++;

  md += sectionNum + ". **Tingkat Keparahan & Urgensi (Severity & Urgency Rating)**\n" +
    "- **Status Kesehatan**: **" + overallSeverity + "**\n" +
    "- **Skor Urgensi**: **" + (criticalLogs.length > 0 ? "9/10 (Sangat Tinggi)" : errorLogs.length > 0 ? "7/10 (Tinggi)" : "4/10 (Sedang)") + "**\n" +
    "- **Catatan**: Laporan ini dihasilkan secara offline menggunakan mesin heuristik lokal dan Knowledge Base (" + kbSize + " entri). Hubungkan API Key untuk analisis AI yang lebih mendalam.";

  return md;
}
