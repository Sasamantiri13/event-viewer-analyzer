/**
 * Event Viewer Analyzer — Google Apps Script Edition
 * Code.gs: Entry point, AI analysis, and server-side API functions
 */

/* ───────── Web App Entry Point ───────── */

function doGet() {
  var html = HtmlService.createHtmlOutputFromFile("Index")
    .setTitle("Event Viewer Analyzer")
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  html.addMetaTag("viewport", "width=device-width, initial-scale=1");
  return html;
}

/* ───────── API Key Management ───────── */

function getGeminiApiKey_() {
  return PropertiesService.getScriptProperties().getProperty("GEMINI_API_KEY") || "";
}

function getOpenAiApiKey_() {
  return PropertiesService.getScriptProperties().getProperty("OPENAI_API_KEY") || "";
}

function checkApiKeys() {
  var gemini = getGeminiApiKey_();
  var openai = getOpenAiApiKey_();
  var kbSize = getKBSize();
  return {
    gemini: gemini.length > 5,
    openai: openai.length > 5,
    kbLoaded: kbSize > 0,
    kbSize: kbSize
  };
}

/* ───────── Knowledge Base from Google Sheets ───────── */

var KB_CACHE_ = null;

function loadKB_() {
  if (KB_CACHE_) return KB_CACHE_;
  
  var props = PropertiesService.getScriptProperties();
  var sheetId = props.getProperty("KB_SHEET_ID");
  
  if (!sheetId) {
    // Try to find by name in the same Drive folder
    var files = DriveApp.getFilesByName("EventViewerAnalyzer_KB");
    if (files.hasNext()) {
      sheetId = files.next().getId();
      props.setProperty("KB_SHEET_ID", sheetId);
    } else {
      Logger.log("KB Sheet not found. Creating one...");
      sheetId = createKBSheet_();
    }
  }
  
  try {
    var ss = SpreadsheetApp.openById(sheetId);
    var sheet = ss.getSheetByName("WindowsEventDB");
    if (!sheet) return [];
    
    var data = sheet.getDataRange().getValues();
    if (data.length <= 1) return []; // Only headers
    
    var headers = data[0];
    var entries = [];
    for (var i = 1; i < data.length; i++) {
      var row = data[i];
      var entry = {};
      for (var j = 0; j < headers.length; j++) {
        entry[headers[j]] = row[j] !== undefined ? String(row[j]) : "";
      }
      entries.push(entry);
    }
    
    KB_CACHE_ = entries;
    return entries;
  } catch (e) {
    Logger.log("Error loading KB: " + e.toString());
    return [];
  }
}

function getKBSize() {
  var kb = loadKB_();
  return kb.length;
}

function lookupKBEntry(eventId) {
  var kb = loadKB_();
  var id = String(eventId);
  for (var i = 0; i < kb.length; i++) {
    if (kb[i]["event-id"] === id) return kb[i];
  }
  return null;
}

function createKBSheet_() {
  var ss = SpreadsheetApp.create("EventViewerAnalyzer_KB");
  var sheet = ss.getActiveSheet();
  sheet.setName("WindowsEventDB");
  sheet.appendRow(["event-id", "legacy-event-id", "criticality", "summary"]);
  
  // Add some essential entries
  var essentialEntries = [
    ["1000", "", "Medium", "Application Error - An application has crashed or encountered a fatal error"],
    ["1001", "", "Medium", "Windows Error Reporting - Application fault bucket information"],
    ["1026", "", "Medium", ".NET Runtime Error - An unhandled exception occurred in a .NET application"],
    ["4624", "", "Low", "Successful Logon - An account was successfully logged on"],
    ["4625", "", "High", "Failed Logon - An account failed to log on"],
    ["4648", "", "Medium", "Explicit Credential Logon - A logon was attempted using explicit credentials"],
    ["4768", "", "Low", "Kerberos Authentication Ticket (TGT) Requested"],
    ["4769", "", "Low", "Kerberos Service Ticket Requested"],
    ["4776", "", "Medium", "NTLM Authentication - Domain controller attempted to validate credentials"],
    ["7000", "", "High", "Service Control Manager - A service failed to start"],
    ["7001", "", "High", "Service Control Manager - A service depends on another service that failed"],
    ["7009", "", "Medium", "Service Control Manager - A timeout was reached while waiting for a service"],
    ["7022", "", "High", "Service Control Manager - A service hung on starting"],
    ["7031", "", "High", "Service Control Manager - A service terminated unexpectedly"],
    ["7034", "", "High", "Service Control Manager - A service terminated unexpectedly (repeated)"],
    ["7036", "", "Low", "Service Control Manager - A service entered the stopped/running state"],
    ["1116", "", "Critical", "Windows Defender - Malware or potentially unwanted software detected"],
    ["1117", "", "High", "Windows Defender - Action taken against malware"],
    ["1118", "", "Critical", "Windows Defender - Failed to take action against malware"],
    ["5001", "", "Critical", "Windows Defender - Real-time protection is disabled"],
    ["5007", "", "High", "Windows Defender - Configuration changed"],
    ["3001", "", "High", "Code Integrity - Driver load blocked due to unsigned or invalid signature"],
    ["3002", "", "High", "Code Integrity - Image hash verification failed"],
    ["3004", "", "High", "Code Integrity - Kernel-mode signing violation"],
    ["19", "", "Low", "Windows Update - Installation successful"],
    ["20", "", "Medium", "Windows Update - Installation failure"],
    ["51", "", "High", "Disk - An error was detected on device during a paging operation"],
    ["55", "", "Critical", "NTFS - File system structure corruption detected"],
    ["7", "", "High", "Disk - Bad block detected"],
    ["11", "", "High", "Disk Controller - Driver detected a controller error"]
  ];
  
  essentialEntries.forEach(function(row) {
    sheet.appendRow(row);
  });
  
  // Create Config sheet
  var configSheet = ss.insertSheet("Config");
  configSheet.appendRow(["key", "value"]);
  configSheet.appendRow(["ai_model", "gemini-2.0-flash"]);
  configSheet.appendRow(["max_logs_to_ai", "50"]);
  configSheet.appendRow(["version", "1.0.0"]);
  
  // Create History sheet
  var historySheet = ss.insertSheet("ServerHistoryDB");
  historySheet.appendRow(["timestamp", "computer", "event_id", "severity"]);
  
  Logger.log("Created KB Sheet: " + ss.getId());
  PropertiesService.getScriptProperties().setProperty("KB_SHEET_ID", ss.getId());
  return ss.getId();
}

/* ───────── Server History DB ───────── */

function logAnalysisHistory(computer, eventId, severity) {
  try {
    var sheetId = PropertiesService.getScriptProperties().getProperty("KB_SHEET_ID");
    if (!sheetId) return;
    var ss = SpreadsheetApp.openById(sheetId);
    var sheet = ss.getSheetByName("ServerHistoryDB");
    if (!sheet) {
      sheet = ss.insertSheet("ServerHistoryDB");
      sheet.appendRow(["timestamp", "computer", "event_id", "severity"]);
    }
    sheet.appendRow([new Date().toISOString(), computer, eventId, severity]);
  } catch (e) {
    Logger.log("Error logging history: " + e.toString());
  }
}

function getServerHistory(computer) {
  try {
    var sheetId = PropertiesService.getScriptProperties().getProperty("KB_SHEET_ID");
    if (!sheetId) return { count: 0, messages: [] };
    var ss = SpreadsheetApp.openById(sheetId);
    var sheet = ss.getSheetByName("ServerHistoryDB");
    if (!sheet) return { count: 0, messages: [] };
    
    var data = sheet.getDataRange().getValues();
    var count = 0;
    for (var i = 1; i < data.length; i++) {
      if (data[i][1] === computer) {
        count++;
      }
    }
    if (count > 1) {
      return { count: count, message: "⚠️ Peringatan: Komputer " + computer + " memiliki riwayat " + count + " masalah sebelumnya di database." };
    }
    return { count: count, message: "" };
  } catch (e) {
    return { count: 0, message: "" };
  }
}

/* ───────── AI Analysis (Gemini / OpenAI / Heuristic Fallback) ───────── */

function analyzeLogs(logsJson, categoryCountsJson, timeFrameText, isMultiFileCorrelation) {
  var logs = JSON.parse(logsJson);
  var categoryCounts = JSON.parse(categoryCountsJson);
  
  if (!logs || logs.length === 0) {
    return JSON.stringify({ error: "No logs provided for analysis." });
  }
  
  var geminiKey = getGeminiApiKey_();
  var openaiKey = getOpenAiApiKey_();
  
  // Format log summary for model input (max 40 logs)
  var formattedLogs = logs.slice(0, 40).map(function(log, idx) {
    return (idx + 1) + ". [" + log.level.toUpperCase() + "] [" + log.timestamp + "] [Source: " + log.source + "] [EventID: " + log.eventId + "]\n" +
      "   Message: " + (log.message || "").substring(0, 300) + (log.message && log.message.length > 300 ? "..." : "") + "\n" +
      "   " + (log.channel ? "Channel: " + log.channel : "") + " " + (log.computer ? "Computer: " + log.computer : "");
  }).join("\n\n");
  
  var statsSummary = Object.keys(categoryCounts).map(function(cat) {
    return cat + ": " + categoryCounts[cat];
  }).join(", ");
  
  // --- 🧠 RAG CONTEXT BUILDING ---
  var uniqueEventIds = {};
  logs.forEach(function(l) { if (l.eventId) uniqueEventIds[l.eventId] = true; });
  var ragContextParts = [];
  
  Object.keys(uniqueEventIds).forEach(function(eid) {
    var kbEntry = lookupKBEntry(eid);
    if (kbEntry && kbEntry.summary) {
      ragContextParts.push("- Event ID " + eid + ": " + kbEntry.summary);
    }
    // Also check Defender Directory
    if (typeof lookupErrorCode !== "undefined") {
      var defMatch = lookupErrorCode(eid);
      if (defMatch) {
        ragContextParts.push("- [Defender] " + defMatch.code + " (" + defMatch.title + "): " + defMatch.description);
      }
    }
  });
  var ragContext = ragContextParts.length > 0 ? "REFERENSI KAMUS RESMI (RAG CONTEXT):\n" + ragContextParts.join("\n") : "";
  // -------------------------------
  
  var systemInstruction = buildSystemInstruction_(timeFrameText, isMultiFileCorrelation);
  var prompt = buildPrompt_(timeFrameText, statsSummary, logs.length, formattedLogs, ragContext);
  
  // Log to history if there is a critical error
  var topComputer = logs[0] ? logs[0].computer : "Unknown";
  var topEventId = logs[0] ? logs[0].eventId : "Unknown";
  var topSeverity = logs[0] ? logs[0].level : "Information";
  if (topSeverity === "Critical" || topSeverity === "Error") {
    logAnalysisHistory(topComputer, topEventId, topSeverity);
  }
  
  // Try Gemini first
  if (geminiKey && geminiKey.length > 5) {
    try {
      var analysis = callGeminiAPI_(geminiKey, systemInstruction, prompt);
      return JSON.stringify({ analysis: analysis, mode: "online-gemini" });
    } catch (e) {
      Logger.log("Gemini API failed: " + e.toString());
    }
  }
  
  // Fallback to OpenAI
  if (openaiKey && openaiKey.length > 5) {
    try {
      var analysis = callOpenAiAPI_(openaiKey, systemInstruction, prompt);
      return JSON.stringify({ analysis: analysis, isOpenAiActive: true, mode: "online-openai" });
    } catch (e) {
      Logger.log("OpenAI API failed: " + e.toString());
    }
  }
  
  // Final fallback: Heuristic + KB
  var heuristicReport = generateHeuristicReport(logs, categoryCounts, timeFrameText, isMultiFileCorrelation);
  return JSON.stringify({
    analysis: heuristicReport,
    isHeuristicFallback: true,
    mode: "offline",
    kbSize: getKBSize()
  });
}

/* ───────── Gemini REST API ───────── */

function callGeminiAPI_(apiKey, systemInstruction, prompt) {
  var url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + apiKey;
  
  var payload = {
    system_instruction: {
      parts: [{ text: systemInstruction }]
    },
    contents: [{
      parts: [{ text: prompt }]
    }],
    generationConfig: {
      temperature: 0.2
    }
  };
  
  var options = {
    method: "post",
    contentType: "application/json",
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  };
  
  var response = UrlFetchApp.fetch(url, options);
  var json = JSON.parse(response.getContentText());
  
  if (json.error) {
    throw new Error("Gemini API Error: " + json.error.message);
  }
  
  if (json.candidates && json.candidates[0] && json.candidates[0].content) {
    return json.candidates[0].content.parts[0].text;
  }
  
  throw new Error("Unexpected Gemini response format");
}

/* ───────── OpenAI REST API ───────── */

function callOpenAiAPI_(apiKey, systemInstruction, prompt) {
  var url = "https://api.openai.com/v1/chat/completions";
  
  var payload = {
    model: "gpt-4o",
    messages: [
      { role: "system", content: systemInstruction },
      { role: "user", content: prompt }
    ],
    temperature: 0.2
  };
  
  var options = {
    method: "post",
    contentType: "application/json",
    headers: { "Authorization": "Bearer " + apiKey },
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  };
  
  var response = UrlFetchApp.fetch(url, options);
  var json = JSON.parse(response.getContentText());
  
  if (json.error) {
    throw new Error("OpenAI API Error: " + json.error.message);
  }
  
  return json.choices[0].message.content;
}

/* ───────── Prompt Builders ───────── */

function buildSystemInstruction_(timeFrameText, isMultiFileCorrelation) {
  var instruction = "Anda adalah seorang Senior Security Analyst & Escalation Engineer dari tim Microsoft Security Response Center.\n" +
    "Tugas Anda adalah melakukan Root Cause Analysis (RCA) berdasarkan log Windows Event Viewer yang diberikan.\n\n" +
    "**INSTRUKSI CHAIN-OF-THOUGHT (CoT):**\n" +
    "1. Baca Referensi Kamus Resmi (RAG) terlebih dahulu sebelum menganalisis log.\n" +
    "2. Identifikasi Pemicu Awal (Root Cause) yang memulai rentetan kejadian.\n" +
    "3. Rekonstruksi Garis Waktu Kejadian (Sebab-Akibat).\n" +
    "4. Jangan menebak arti kode error jika tidak tahu, gunakan referensi RAG yang diberikan.\n\n";
  
  if (isMultiFileCorrelation) {
    instruction += "**INSTRUKSI KHUSUS MULTI-FILE CORRELATION**: Administrator telah mengunggah 2 file log yang berbeda. Lakukan Korelasi Silang secara cerdas.\n\n";
  }
  
  instruction += "Format response harus menggunakan Markdown yang rapi dengan bagian:\n" +
    "1. Ringkasan Eksekutif & Tingkat Keparahan (Cantumkan Confidence Level % Anda)\n" +
    "2. Rekonstruksi Timeline & Akar Masalah (Root Cause)\n" +
    "3. Analisis Teknis Mendalam (Hubungkan Event ID dengan bukti yang ada)\n" +
    (isMultiFileCorrelation ? "4. Korelasi Silang 2 Berkas\n5. Rekomendasi Mitigasi\n6. Skrip Remediasi Otomatis" :
      "4. Rekomendasi Mitigasi\n5. Skrip Remediasi Otomatis") + "\n\n" +
    "**PENTING UNTUK SKRIP REMEDIASI:**\n" +
    "Jika memungkinkan, berikan satu blok kode PowerShell yang jelas dan aman (menggunakan ```powershell ... ```) untuk mengatasi masalah (misal: mereset service, update signature, sfc scan, dll). Skrip ini akan diekstrak oleh sistem.\n\n" +
    "Gunakan nada bicara yang sangat teknis, analitis, profesional, dan dalam Bahasa Indonesia.";
  
  return instruction;
}

function buildPrompt_(timeFrameText, statsSummary, logCount, formattedLogs, ragContext) {
  return "Berikut adalah data statistik log:\n" +
    "- Timeframe analisis: " + (timeFrameText || "3 jam terakhir") + "\n" +
    "- Distribusi kategori: " + (statsSummary || "N/A") + "\n" +
    "- Jumlah log kritis yang diekstrak: " + logCount + " log.\n\n" +
    (ragContext ? ragContext + "\n\n" : "") +
    "Berikut adalah detail dari log-log berurutan waktu (urutan bisa dari terbaru ke terlama atau sebaliknya, harap periksa timestamp):\n```text\n" + formattedLogs + "\n```\n\n" +
    "Silakan lakukan Analisis Akar Masalah (RCA) mendalam berdasarkan data di atas.";
}

/* ───────── Utility: Save API Key ───────── */

function saveApiKey(keyName, keyValue) {
  PropertiesService.getScriptProperties().setProperty(keyName, keyValue);
  return { success: true, message: "API Key '" + keyName + "' berhasil disimpan." };
}

/* ───────── Utility: Get scenarios for client ───────── */

function getScenariosForClient() {
  return JSON.stringify(generateScenarios());
}

/* ───────── Enterprise Features: Export & Alerts ───────── */

function exportToGoogleDoc(markdownText) {
  try {
    var title = "Laporan Analisis Event Viewer - " + Utilities.formatDate(new Date(), "Asia/Jakarta", "yyyy-MM-dd HH:mm");
    var doc = DocumentApp.create(title);
    var body = doc.getBody();
    
    // Simple markdown to Google Docs formatting
    var lines = markdownText.split("\n");
    for (var i = 0; i < lines.length; i++) {
      var line = lines[i];
      if (line.indexOf("### ") === 0) {
        body.appendParagraph(line.substring(4)).setHeading(DocumentApp.ParagraphHeading.HEADING3);
      } else if (line.indexOf("## ") === 0) {
        body.appendParagraph(line.substring(3)).setHeading(DocumentApp.ParagraphHeading.HEADING2);
      } else if (line.indexOf("# ") === 0) {
        body.appendParagraph(line.substring(2)).setHeading(DocumentApp.ParagraphHeading.HEADING1);
      } else if (line.indexOf("- ") === 0) {
        body.appendListItem(line.substring(2)).setGlyphType(DocumentApp.GlyphType.BULLET);
      } else if (line.indexOf("1. ") === 0 || /^\d+\.\s/.test(line)) {
        body.appendListItem(line.replace(/^\d+\.\s/, "")).setGlyphType(DocumentApp.GlyphType.NUMBER);
      } else if (line.trim() !== "") {
        // Handle bold basic
        var p = body.appendParagraph(line.replace(/\*\*/g, ""));
        // A more advanced script would parse bold accurately, we do a simple append here
      }
    }
    
    doc.saveAndClose();
    return { success: true, url: doc.getUrl(), name: title };
  } catch (e) {
    return { success: false, error: e.toString() };
  }
}

function sendIncidentEmail(reportHtml, recipient, severity) {
  try {
    if (!recipient || recipient.indexOf("@") === -1) {
      throw new Error("Alamat email tidak valid.");
    }
    
    var subject = "[ALERT - " + severity + "] Insiden Keamanan / Sistem Terdeteksi";
    var bodyText = "Laporan analisis sistem menunjukkan adanya insiden.\n\nSilakan buka HTML viewer atau aplikasi Event Viewer Analyzer untuk membaca selengkapnya.";
    
    var finalHtml = "<div style='font-family:sans-serif;max-width:800px;margin:0 auto;border:1px solid #e2e8f0;border-radius:8px;padding:20px;background:#f8fafc'>" +
      "<h2 style='color:" + (severity === "Critical" ? "#dc2626" : "#ea580c") + "'>🚨 Peringatan Insiden Sistem</h2>" +
      "<div style='background:#fff;padding:16px;border-radius:6px;border:1px solid #e2e8f0;'>" + reportHtml + "</div>" +
      "<p style='font-size:11px;color:#64748b;margin-top:20px;text-align:center'>Dikirim secara otomatis dari Event Viewer Analyzer (Google Apps Script)</p>" +
      "</div>";

    MailApp.sendEmail({
      to: recipient,
      subject: subject,
      body: bodyText,
      htmlBody: finalHtml
    });
    
    return { success: true, message: "Email peringatan berhasil dikirim ke " + recipient };
  } catch (e) {
    return { success: false, error: e.toString() };
  }
}
